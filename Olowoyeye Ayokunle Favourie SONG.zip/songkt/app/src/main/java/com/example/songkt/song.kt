package com.example.song.kt

fun main(args: Array<Thread>) {
/* My favourite song is Intentions performed by Justin Beiber and Quavo , this contains all the details describing the
song including title, artist, date of release etc.
 */
    val songTitle: String = "Intentions"
    print(songTitle)
    val songArtist: String = "Justin Beiber featuring Quavo"
    print(songArtist)
    val songGenre: String = "Pop"
    print(songGenre)
    val songRealeaseDate: String = "February 7, 2020"
    print(songRealeaseDate)
    val songLength: String = "3:32"
    print(songLength)
    val songLabel: String = "Def Jam"
    print(songLabel)
    var songNominatedForMtvVma: Boolean = true
    //"Intentions" was nominated for "Best Pop Video" at the 2020 MTV Video Music Awards.
    print(songNominatedForMtvVma)
    val songProducer: String = "Poo Bear"
    print(songProducer)
    val songWriters: String = "Justin Bieber, Quavious Marshall, Jason Boyd, Dominic Jordan, Jimmy Giannos"
    print(songWriters)
    val songlength: String = "3:32"
    print(songlength)
    val songDonations: Int = 10000
    print(songDonations)
    // This amount was donated in dollars within the first 3 days of realease to a charity.







}